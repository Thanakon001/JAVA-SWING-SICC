/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package thanakon;

import javax.swing.WindowConstants;

/**
 *
 * @author Thanakon Sanesri
 */
public class Thanakon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // สร้างตัว instant ของ home หรือการกำหนดตัวแปรของ HomePage ที่สร้าง
        HomePage app = new HomePage();
        app.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        app.setVisible(true);
    }
    
}
