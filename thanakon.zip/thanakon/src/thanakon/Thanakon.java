/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package thanakon;

//import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import popup.Login;

/**
 *
 * @author Thanakon Sanesri
 */
public class Thanakon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //ตั้งค่า Message popup รองรับภาษาไทย
        UIManager.put("OptionPane.messageFont", new Font("Mali", Font.PLAIN, 14));
        //Microsoft Sans Serif

        //ปรับเเต่ง ui ให้ใหม่ขึ้น นิดนึง
        FlatLightLaf.setup();
//      FlatDarkLaf.setup();

        // สร้างตัว instant ของ home หรือการกำหนดตัวแปรของ HomePage ที่สร้าง
        Login app = new Login();
        app.setLocationRelativeTo(null);
        app.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        app.setVisible(true);
    }
    
}
