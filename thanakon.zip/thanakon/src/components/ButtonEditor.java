/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package components;

import java.awt.Component;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import popup.DeleteUser;
import popup.EditUser;

/**
 *
 * @author Thanakon Sanesri
 */
public class ButtonEditor extends DefaultCellEditor {

    private JButton button;
    private String label;
    private JTable table;

    public ButtonEditor(JCheckBox check, JTable table, String label) {
        super(check);
        button = new JButton();
        button.setOpaque(true);
        this.label = label;
        this.table = table;

        button.addActionListener(e -> {
            int row = table.getSelectedRow();

            if (label.equals("edit")) {
                System.out.println(row + "edit");

                String m_user = (String) table.getValueAt(row, 1);
                String m_pass = (String) table.getValueAt(row, 2);
                String m_name = (String) table.getValueAt(row, 3);
                String m_phone = (String) table.getValueAt(row, 4);

                EditUser popup = new EditUser();
                popup.setTable(table);
                popup.setData(m_user, m_pass, m_name, m_phone);
                popup.setLocationRelativeTo(null);
                popup.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                popup.setVisible(true);

            } else {
                System.out.println(row + "delete");

                String m_user = (String) table.getValueAt(row, 1);
                String m_pass = (String) table.getValueAt(row, 2);
                String m_name = (String) table.getValueAt(row, 3);
                String m_phone = (String) table.getValueAt(row, 4);

                DeleteUser popup = new DeleteUser();
                popup.setTable(table);
                popup.setData(m_user, m_pass, m_name, m_phone);
                popup.setLocationRelativeTo(null);
                popup.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                popup.setVisible(true);
            }

        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        button.setText(label);
        return button;
    }

}
