/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

/**
 *
 * @author Thanakon Sanesri
 */
public class SessionManager {

    private static String name = "";

    public static void sessionAuthLoggedSave(String name) {
        SessionManager.name = name;
    }

    public static void sessionAuthLoggedClose(String name) {
        SessionManager.name = "";
    }

    public static String getAuthNameSession() {
        return SessionManager.name;
    }
}
