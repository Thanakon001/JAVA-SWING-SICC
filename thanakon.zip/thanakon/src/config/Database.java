/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Thanakon Sanesri
 */
public class Database {

    //ตัวแปรที่มีค่าเริ่มต้นไม่สามารถเปลี่ยนแปลงได้ หลังจากเริมโปรแกรม
    private final String url = "jdbc:mariadb://localhost:3306/thanakon";
    private final String user = "root";
    private final String pass = "";

    //ตัวแปรใช้งานภายนอกเกี่ยวกับ Database หรือ ฐานข้อมูลระบบ
    public Connection conn;
    public Statement stmt;
    public ResultSet result;

    //funtion เชื่อมต่อ ฐานข้อมูล
    public Connection getConnection() {
        try {
            conn = DriverManager.getConnection(url, user, pass);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return conn;
    }

    //function ดึง query ข้อมูล
    public ResultSet getQuery(String sql) {
        try {
            stmt = conn.createStatement();
            result = stmt.executeQuery(sql);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return result;
    }

    //function commit ข้อมูล
    public boolean getCommit(String sql) {
        try {
            stmt = conn.createStatement();
            result = stmt.executeQuery(sql);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            return false;
        }
        return true;
    }

    //ปิดการเชื่อมต่อ ฐานข้อมูล
    public void disConnetion() {
        try {
            conn.close();
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

}
