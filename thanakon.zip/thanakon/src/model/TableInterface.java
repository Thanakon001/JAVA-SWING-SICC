/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import config.Database;
import java.awt.Font;
import javax.swing.JTable;
import java.sql.*;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 *
 * @author Thanakon Sanesri
 */
public interface TableInterface {
    
    public static void getDataTable(JTable table, String sql) {
        try {
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setColumnCount(0);
            model.setRowCount(0);
            
            JTableHeader tableHeader = table.getTableHeader();
            tableHeader.setFont(new Font("Mali", Font.PLAIN, 14));
            
            model.addColumn("ลำดับ");
            model.addColumn("ชื่อผู้ใช้");
            model.addColumn("รหัสผ่าน");
            model.addColumn("ชื่อ-สกุล");
            model.addColumn("เบอร์โทรศัพท์");
            model.addColumn("แก้ไข");
            model.addColumn("ลบ");

            //สร้าง instants ของ class Database ที่ไว้ติดต่อฐานข้อมูล
            Database db = new Database();
            db.getConnection();

            //นำผลลัพธ์ที่ได้จากการ query หรือดึงข้อมูลจากฐานข้อมูลมาเก็บไว้ใน result
            ResultSet result = db.getQuery(sql);
            
            int i = 1;
            while (result.next()) {
                //loop หรือวนข้อมูลเพื่อเก็บข้อมูลไว้ใน item vector เพื่อนำไปแสดงในตาราง
                Vector<Object> item = new Vector<>();
                item.add(i++);
                item.add(result.getString("m_user"));
                item.add(result.getString("m_pass"));
                item.add(result.getString("m_name"));
                item.add(result.getString("m_phone"));
                
                //เพื่อข้อมูลที่ loop ไว้ใน table
                model.addRow(item);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
}
