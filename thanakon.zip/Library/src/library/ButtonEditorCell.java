/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

import java.awt.Component;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @author Thanakon Sanesri
 */
public class ButtonEditorCell extends DefaultCellEditor {

    private String label;
    private JButton button;
    private JTable table;

    public ButtonEditorCell(JCheckBox check, JTable table, String label) {
        super(check);
        this.table = table;
        this.label = label;

        this.button = new JButton();
        button.setOpaque(true);

        button.addActionListener(e -> {

            Window window = SwingUtilities.windowForComponent(button);
            if (window != null) {
                window.dispose();
            }

            int row = table.getSelectedRow();

            String user = (String) table.getValueAt(row, 0);
            String pass = (String) table.getValueAt(row, 1);
            String name = (String) table.getValueAt(row, 2);
            String tel = (String) table.getValueAt(row, 3);

            if (label.equals("edit")) {

                EditUser editUser = new EditUser();
                editUser.setDataField(user, pass, name, tel);
                editUser.setVisible(true);
                editUser.setLocationRelativeTo(null);

                editUser.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

                editUser.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {

                        MainApp homePage = new MainApp();
                        homePage.setVisible(true);
                        homePage.pack();
                    }
                });
            } else if (label.equals("delete")) {
                DeleteUser deleteUser = new DeleteUser();
                deleteUser.setDataField(user, pass, name, tel);
                deleteUser.setVisible(true);
                deleteUser.setLocationRelativeTo(null);

                deleteUser.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

                deleteUser.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        MainApp homePage = new MainApp();
                        homePage.setVisible(true);
                    }
                });
            }
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        button.setText(label);
        return button;
    }

}
