/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package library;

import java.awt.Font;
import javax.swing.UIManager;

/**
 *
 * @author Thanakon Sanesri
 */
public class Library {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Font font = new Font("Microsoft Sans Serif", Font.PLAIN, 16);  
        UIManager.put("OptionPane.messageFont", font);

        MainApp homePage = new MainApp();
        homePage.setVisible(true);
        homePage.pack();
    }

}
