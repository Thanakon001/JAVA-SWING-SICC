/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Thanakon Sanesri
 */
public class Database {

    private Connection conn;
    private Statement stmt;
    private ResultSet result;

    private int row;

    private final String url = "jdbc:mariadb://localhost:3306/db_library";
    private final String user = "root";
    private final String pass = "";

    public Database() {
        try {
            conn = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public Connection getConnetion() {
        try {
            conn = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return conn;
    }

    public ResultSet query(String sql) {
        try {
            stmt = conn.createStatement();
            result = stmt.executeQuery(sql);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            this.disconnect();
        }
        return result;
    }

    public int commit(String sql) {
        try {
            stmt = conn.createStatement();
            row = stmt.executeUpdate(sql);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally {
            this.disconnect();
        }
        return row;
    }

    public void disconnect() {
        try {
            conn.close();
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

}
